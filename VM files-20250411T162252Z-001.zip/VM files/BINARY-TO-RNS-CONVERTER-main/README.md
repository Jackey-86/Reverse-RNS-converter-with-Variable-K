# BINARY-TO-RNS-CONVERTER
A fast hardware for performing binary to RNS conversion implemented in VHDL and synthesized on Spartan 3 FPGA
