#include <stdio.h>
#include <stdlib.h>

int main()
{
    int input_1, input_2,input_3;
    // taking inputs
    printf("please enter your first input \n");
    scanf("%d", &input_1);
    printf("please enter your second input \n");
    scanf("%d", &input_2);
    printf("please enter your third input \n");
    scanf("%d", &input_3);

    int Max = input_1*input_2*input_3;
    printf("Your maximum number is %d\n", Max);


    for(int count =0; count<=Max; count++){
        int firstMod = count%input_1;
        int secondMod = count%input_2;
        int thirdMod = count%input_3;

    printf("Your moduli set of %d is %d %d %d\n",count, firstMod, secondMod, thirdMod);

    }

    return 0;
}
