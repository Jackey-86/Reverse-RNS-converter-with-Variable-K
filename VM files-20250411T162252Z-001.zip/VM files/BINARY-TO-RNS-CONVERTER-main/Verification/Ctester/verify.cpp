#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>

using namespace std;

struct Reading
{
    int mod_base;
    int mod_index_0, mod_index_1, mod_index_2;

    Reading(int mod_base, int mod_index_0, int mod_index_1, int mod_index_2)
    {
        Reading::mod_base = mod_base;
        Reading::mod_index_0 = mod_index_0;
        Reading::mod_index_1 = mod_index_1;
        Reading::mod_index_2 = mod_index_2;
    }
};

int main()
{
    cout << "Enter output Forward Converter Output File: " << endl;
    string ifile;
    cin >> ifile;
    cout << "Enter moduli set seperated by space: " << endl;
    int m, n, p;
    cin >> m >> n >> p;

    // handle input file stream
    ifstream ist(ifile);
    if (!ist)
        throw runtime_error("can't open input file " + ifile);

    string ofile = "verified" + to_string(m) + to_string(n) + to_string(p) + ".txt";
    string fofile = "failed" + to_string(m) + to_string(n) + to_string(p) + ".txt";
    ofstream ost(ofile);
    ofstream fost(fofile);

    vector<Reading> tmp_mod;
    int mod_base;
    int mod_index_0, mod_index_1, mod_index_2;
    string temp, temp1, temp2, temp3, temp4, temp5, temp6, temp7;

    while (ist >> mod_base >> temp >> temp1 >> mod_index_0 >> mod_index_1 >> mod_index_2 >> temp2 >> temp3 >> temp4 >> temp5 >> temp6 >> temp7)
    {
        tmp_mod.push_back(Reading(mod_base, mod_index_0, mod_index_1, mod_index_2));
    }

    int a = 0, b = 0; // stores number of fails and passed

    for (int i = 0; i < tmp_mod.size(); i++)
    {
        if ((tmp_mod[i].mod_base % m) == tmp_mod[i].mod_index_0 && (tmp_mod[i].mod_base % n) == tmp_mod[i].mod_index_1 && (tmp_mod[i].mod_base % p) == tmp_mod[i].mod_index_2)
        {
            ost << "mod " << m << n << p << " " << i << " passed\n";
            a++;
        }
        else
        {
            fost << "mod " << m << n << p << " " << i << " failed\n";
            b++;
        }
    }
    ost << "Total Passed: " << a << "\nTotal Failed: " << b << endl;
    fost << "Total Failed: " << b << "\nTotal Passed: " << a << endl;
}