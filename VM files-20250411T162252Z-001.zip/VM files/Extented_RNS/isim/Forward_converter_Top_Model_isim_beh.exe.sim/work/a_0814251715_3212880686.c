/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/VM_files/RNS - Foward Converter/MOD78K_Datapath.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_10420449594411817395_1035706684(char *, char *, int , int );
unsigned char ieee_p_2592010699_sub_3488546069778340532_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_3488768496604610246_503743352(char *, unsigned char , unsigned char );


static void work_a_0814251715_3212880686_p_0(char *t0)
{
    char t10[16];
    char t12[16];
    char t17[16];
    char *t1;
    char *t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    char *t9;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t18;
    int t19;
    unsigned char t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    xsi_set_current_line(193, ng0);

LAB3:    t1 = (t0 + 29104);
    t3 = (t0 + 7256U);
    t4 = *((char **)t3);
    t5 = (3 - 1);
    t6 = (11 - t5);
    t7 = (t6 * 1U);
    t8 = (0 + t7);
    t3 = (t4 + t8);
    t11 = ((IEEE_P_2592010699) + 4000);
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 0;
    t14 = (t13 + 4U);
    *((int *)t14) = 1;
    t14 = (t13 + 8U);
    *((int *)t14) = 1;
    t15 = (1 - 0);
    t16 = (t15 * 1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t17 + 0U);
    t18 = (t14 + 0U);
    *((int *)t18) = 2;
    t18 = (t14 + 4U);
    *((int *)t18) = 0;
    t18 = (t14 + 8U);
    *((int *)t18) = -1;
    t19 = (0 - 2);
    t16 = (t19 * -1);
    t16 = (t16 + 1);
    t18 = (t14 + 12U);
    *((unsigned int *)t18) = t16;
    t9 = xsi_base_array_concat(t9, t10, t11, (char)97, t1, t12, (char)97, t3, t17, (char)101);
    t16 = (2U + 3U);
    t20 = (5U != t16);
    if (t20 == 1)
        goto LAB5;

LAB6:    t18 = (t0 + 18064);
    t21 = (t18 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t9, 5U);
    xsi_driver_first_trans_fast(t18);

LAB2:    t25 = (t0 + 17680);
    *((int *)t25) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(5U, t16, 0);
    goto LAB6;

}

static void work_a_0814251715_3212880686_p_1(char *t0)
{
    char t11[16];
    char t13[16];
    char t18[16];
    char *t1;
    char *t3;
    char *t4;
    int t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t12;
    char *t14;
    char *t15;
    int t16;
    unsigned int t17;
    char *t19;
    int t20;
    unsigned char t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;

LAB0:    xsi_set_current_line(194, ng0);

LAB3:    t1 = (t0 + 29106);
    t3 = (t0 + 7256U);
    t4 = *((char **)t3);
    t5 = (2 * 3);
    t6 = (t5 - 1);
    t7 = (11 - t6);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t3 = (t4 + t9);
    t12 = ((IEEE_P_2592010699) + 4000);
    t14 = (t13 + 0U);
    t15 = (t14 + 0U);
    *((int *)t15) = 0;
    t15 = (t14 + 4U);
    *((int *)t15) = 1;
    t15 = (t14 + 8U);
    *((int *)t15) = 1;
    t16 = (1 - 0);
    t17 = (t16 * 1);
    t17 = (t17 + 1);
    t15 = (t14 + 12U);
    *((unsigned int *)t15) = t17;
    t15 = (t18 + 0U);
    t19 = (t15 + 0U);
    *((int *)t19) = 5;
    t19 = (t15 + 4U);
    *((int *)t19) = 3;
    t19 = (t15 + 8U);
    *((int *)t19) = -1;
    t20 = (3 - 5);
    t17 = (t20 * -1);
    t17 = (t17 + 1);
    t19 = (t15 + 12U);
    *((unsigned int *)t19) = t17;
    t10 = xsi_base_array_concat(t10, t11, t12, (char)97, t1, t13, (char)97, t3, t18, (char)101);
    t17 = (2U + 3U);
    t21 = (5U != t17);
    if (t21 == 1)
        goto LAB5;

LAB6:    t19 = (t0 + 18128);
    t22 = (t19 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t10, 5U);
    xsi_driver_first_trans_fast(t19);

LAB2:    t26 = (t0 + 17696);
    *((int *)t26) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(5U, t17, 0);
    goto LAB6;

}

static void work_a_0814251715_3212880686_p_2(char *t0)
{
    char t11[16];
    char t13[16];
    char t18[16];
    char *t1;
    char *t3;
    char *t4;
    int t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t12;
    char *t14;
    char *t15;
    int t16;
    unsigned int t17;
    char *t19;
    int t20;
    unsigned char t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;

LAB0:    xsi_set_current_line(195, ng0);

LAB3:    t1 = (t0 + 29108);
    t3 = (t0 + 7256U);
    t4 = *((char **)t3);
    t5 = (3 * 3);
    t6 = (t5 - 1);
    t7 = (11 - t6);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t3 = (t4 + t9);
    t12 = ((IEEE_P_2592010699) + 4000);
    t14 = (t13 + 0U);
    t15 = (t14 + 0U);
    *((int *)t15) = 0;
    t15 = (t14 + 4U);
    *((int *)t15) = 1;
    t15 = (t14 + 8U);
    *((int *)t15) = 1;
    t16 = (1 - 0);
    t17 = (t16 * 1);
    t17 = (t17 + 1);
    t15 = (t14 + 12U);
    *((unsigned int *)t15) = t17;
    t15 = (t18 + 0U);
    t19 = (t15 + 0U);
    *((int *)t19) = 8;
    t19 = (t15 + 4U);
    *((int *)t19) = 6;
    t19 = (t15 + 8U);
    *((int *)t19) = -1;
    t20 = (6 - 8);
    t17 = (t20 * -1);
    t17 = (t17 + 1);
    t19 = (t15 + 12U);
    *((unsigned int *)t19) = t17;
    t10 = xsi_base_array_concat(t10, t11, t12, (char)97, t1, t13, (char)97, t3, t18, (char)101);
    t17 = (2U + 3U);
    t21 = (5U != t17);
    if (t21 == 1)
        goto LAB5;

LAB6:    t19 = (t0 + 18192);
    t22 = (t19 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t10, 5U);
    xsi_driver_first_trans_fast(t19);

LAB2:    t26 = (t0 + 17712);
    *((int *)t26) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(5U, t17, 0);
    goto LAB6;

}

static void work_a_0814251715_3212880686_p_3(char *t0)
{
    char t11[16];
    char t13[16];
    char t18[16];
    char *t1;
    char *t3;
    char *t4;
    int t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t12;
    char *t14;
    char *t15;
    int t16;
    unsigned int t17;
    char *t19;
    int t20;
    unsigned char t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;

LAB0:    xsi_set_current_line(196, ng0);

LAB3:    t1 = (t0 + 29110);
    t3 = (t0 + 7256U);
    t4 = *((char **)t3);
    t5 = (4 * 3);
    t6 = (t5 - 1);
    t7 = (11 - t6);
    t8 = (t7 * 1U);
    t9 = (0 + t8);
    t3 = (t4 + t9);
    t12 = ((IEEE_P_2592010699) + 4000);
    t14 = (t13 + 0U);
    t15 = (t14 + 0U);
    *((int *)t15) = 0;
    t15 = (t14 + 4U);
    *((int *)t15) = 1;
    t15 = (t14 + 8U);
    *((int *)t15) = 1;
    t16 = (1 - 0);
    t17 = (t16 * 1);
    t17 = (t17 + 1);
    t15 = (t14 + 12U);
    *((unsigned int *)t15) = t17;
    t15 = (t18 + 0U);
    t19 = (t15 + 0U);
    *((int *)t19) = 11;
    t19 = (t15 + 4U);
    *((int *)t19) = 9;
    t19 = (t15 + 8U);
    *((int *)t19) = -1;
    t20 = (9 - 11);
    t17 = (t20 * -1);
    t17 = (t17 + 1);
    t19 = (t15 + 12U);
    *((unsigned int *)t19) = t17;
    t10 = xsi_base_array_concat(t10, t11, t12, (char)97, t1, t13, (char)97, t3, t18, (char)101);
    t17 = (2U + 3U);
    t21 = (5U != t17);
    if (t21 == 1)
        goto LAB5;

LAB6:    t19 = (t0 + 18256);
    t22 = (t19 + 56U);
    t23 = *((char **)t22);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    memcpy(t25, t10, 5U);
    xsi_driver_first_trans_fast(t19);

LAB2:    t26 = (t0 + 17728);
    *((int *)t26) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(5U, t17, 0);
    goto LAB6;

}

static void work_a_0814251715_3212880686_p_4(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    xsi_set_current_line(200, ng0);

LAB3:    t2 = (t0 + 10712U);
    t3 = *((char **)t2);
    t4 = *((int *)t3);
    t2 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t1, t4, 5);
    t5 = (t0 + 18320);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 5U);
    xsi_driver_first_trans_fast(t5);

LAB2:    t10 = (t0 + 17744);
    *((int *)t10) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_5(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    xsi_set_current_line(217, ng0);

LAB3:    t2 = (t0 + 10832U);
    t3 = *((char **)t2);
    t4 = *((int *)t3);
    t2 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t1, t4, 5);
    t5 = (t0 + 18384);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 5U);
    xsi_driver_first_trans_fast(t5);

LAB2:    t10 = (t0 + 17760);
    *((int *)t10) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_6(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    xsi_set_current_line(218, ng0);

LAB3:    t2 = (t0 + 10952U);
    t3 = *((char **)t2);
    t4 = *((int *)t3);
    t2 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t1, t4, 5);
    t5 = (t0 + 18448);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t2, 5U);
    xsi_driver_first_trans_fast(t5);

LAB2:    t10 = (t0 + 17776);
    *((int *)t10) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_7(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(236, ng0);

LAB3:    t1 = (t0 + 7256U);
    t2 = *((char **)t1);
    t3 = (11 - 5);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 18512);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 6U);
    xsi_driver_first_trans_fast(t6);

LAB2:    t11 = (t0 + 17792);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_8(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(237, ng0);

LAB3:    t1 = (t0 + 7256U);
    t2 = *((char **)t1);
    t3 = (11 - 4);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 18576);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 5U);
    xsi_driver_first_trans_fast(t6);

LAB2:    t11 = (t0 + 17808);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_9(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(238, ng0);

LAB3:    t1 = (t0 + 7256U);
    t2 = *((char **)t1);
    t3 = (11 - 3);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 18640);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast(t6);

LAB2:    t11 = (t0 + 17824);
    *((int *)t11) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_10(char *t0)
{
    char t10[16];
    char t12[16];
    char t17[16];
    char *t1;
    char *t3;
    char *t4;
    int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    char *t9;
    char *t11;
    char *t13;
    char *t14;
    int t15;
    unsigned int t16;
    char *t18;
    int t19;
    unsigned char t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;

LAB0:    xsi_set_current_line(259, ng0);

LAB3:    t1 = (t0 + 29112);
    t3 = (t0 + 8696U);
    t4 = *((char **)t3);
    t5 = (3 - 1);
    t6 = (4 - t5);
    t7 = (t6 * 1U);
    t8 = (0 + t7);
    t3 = (t4 + t8);
    t11 = ((IEEE_P_2592010699) + 4000);
    t13 = (t12 + 0U);
    t14 = (t13 + 0U);
    *((int *)t14) = 0;
    t14 = (t13 + 4U);
    *((int *)t14) = 1;
    t14 = (t13 + 8U);
    *((int *)t14) = 1;
    t15 = (1 - 0);
    t16 = (t15 * 1);
    t16 = (t16 + 1);
    t14 = (t13 + 12U);
    *((unsigned int *)t14) = t16;
    t14 = (t17 + 0U);
    t18 = (t14 + 0U);
    *((int *)t18) = 2;
    t18 = (t14 + 4U);
    *((int *)t18) = 0;
    t18 = (t14 + 8U);
    *((int *)t18) = -1;
    t19 = (0 - 2);
    t16 = (t19 * -1);
    t16 = (t16 + 1);
    t18 = (t14 + 12U);
    *((unsigned int *)t18) = t16;
    t9 = xsi_base_array_concat(t9, t10, t11, (char)97, t1, t12, (char)97, t3, t17, (char)101);
    t16 = (2U + 3U);
    t20 = (5U != t16);
    if (t20 == 1)
        goto LAB5;

LAB6:    t18 = (t0 + 18704);
    t21 = (t18 + 56U);
    t22 = *((char **)t21);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    memcpy(t24, t9, 5U);
    xsi_driver_first_trans_fast(t18);

LAB2:    t25 = (t0 + 17840);
    *((int *)t25) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(5U, t16, 0);
    goto LAB6;

}

static void work_a_0814251715_3212880686_p_11(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    int t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    int t14;
    int t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    xsi_set_current_line(308, ng0);

LAB3:    t1 = (t0 + 9976U);
    t2 = *((char **)t1);
    t1 = (t0 + 11072U);
    t3 = *((char **)t1);
    t4 = *((int *)t3);
    t5 = (t4 - 1);
    t6 = (t5 - 4);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t10 = *((unsigned char *)t1);
    t11 = (t0 + 8696U);
    t12 = *((char **)t11);
    t11 = (t0 + 11072U);
    t13 = *((char **)t11);
    t14 = *((int *)t13);
    t15 = (t14 - 1);
    t16 = (t15 - 4);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t11 = (t12 + t19);
    t20 = *((unsigned char *)t11);
    t21 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t10, t20);
    t22 = (t0 + 18768);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = t21;
    xsi_driver_first_trans_delta(t22, 3U, 1, 0LL);

LAB2:    t27 = (t0 + 17856);
    *((int *)t27) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_12(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    int t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    int t14;
    int t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    xsi_set_current_line(308, ng0);

LAB3:    t1 = (t0 + 9976U);
    t2 = *((char **)t1);
    t1 = (t0 + 11192U);
    t3 = *((char **)t1);
    t4 = *((int *)t3);
    t5 = (t4 - 1);
    t6 = (t5 - 4);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t10 = *((unsigned char *)t1);
    t11 = (t0 + 8696U);
    t12 = *((char **)t11);
    t11 = (t0 + 11192U);
    t13 = *((char **)t11);
    t14 = *((int *)t13);
    t15 = (t14 - 1);
    t16 = (t15 - 4);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t11 = (t12 + t19);
    t20 = *((unsigned char *)t11);
    t21 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t10, t20);
    t22 = (t0 + 18832);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = t21;
    xsi_driver_first_trans_delta(t22, 2U, 1, 0LL);

LAB2:    t27 = (t0 + 17872);
    *((int *)t27) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_13(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    int t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    int t14;
    int t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    xsi_set_current_line(308, ng0);

LAB3:    t1 = (t0 + 9976U);
    t2 = *((char **)t1);
    t1 = (t0 + 11312U);
    t3 = *((char **)t1);
    t4 = *((int *)t3);
    t5 = (t4 - 1);
    t6 = (t5 - 4);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t10 = *((unsigned char *)t1);
    t11 = (t0 + 8696U);
    t12 = *((char **)t11);
    t11 = (t0 + 11312U);
    t13 = *((char **)t11);
    t14 = *((int *)t13);
    t15 = (t14 - 1);
    t16 = (t15 - 4);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t11 = (t12 + t19);
    t20 = *((unsigned char *)t11);
    t21 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t10, t20);
    t22 = (t0 + 18896);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = t21;
    xsi_driver_first_trans_delta(t22, 1U, 1, 0LL);

LAB2:    t27 = (t0 + 17888);
    *((int *)t27) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_14(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(311, ng0);

LAB3:    t1 = (t0 + 9976U);
    t2 = *((char **)t1);
    t3 = (3 - 4);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 18960);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast_port(t8);

LAB2:    t13 = (t0 + 17904);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_15(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    int t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    int t14;
    int t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    xsi_set_current_line(316, ng0);

LAB3:    t1 = (t0 + 10136U);
    t2 = *((char **)t1);
    t1 = (t0 + 11432U);
    t3 = *((char **)t1);
    t4 = *((int *)t3);
    t5 = (t4 - 1);
    t6 = (t5 - 4);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t10 = *((unsigned char *)t1);
    t11 = (t0 + 8856U);
    t12 = *((char **)t11);
    t11 = (t0 + 11432U);
    t13 = *((char **)t11);
    t14 = *((int *)t13);
    t15 = (t14 - 1);
    t16 = (t15 - 4);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t11 = (t12 + t19);
    t20 = *((unsigned char *)t11);
    t21 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t10, t20);
    t22 = (t0 + 19024);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = t21;
    xsi_driver_first_trans_delta(t22, 3U, 1, 0LL);

LAB2:    t27 = (t0 + 17920);
    *((int *)t27) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_16(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    int t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    int t14;
    int t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    xsi_set_current_line(316, ng0);

LAB3:    t1 = (t0 + 10136U);
    t2 = *((char **)t1);
    t1 = (t0 + 11552U);
    t3 = *((char **)t1);
    t4 = *((int *)t3);
    t5 = (t4 - 1);
    t6 = (t5 - 4);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t10 = *((unsigned char *)t1);
    t11 = (t0 + 8856U);
    t12 = *((char **)t11);
    t11 = (t0 + 11552U);
    t13 = *((char **)t11);
    t14 = *((int *)t13);
    t15 = (t14 - 1);
    t16 = (t15 - 4);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t11 = (t12 + t19);
    t20 = *((unsigned char *)t11);
    t21 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t10, t20);
    t22 = (t0 + 19088);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = t21;
    xsi_driver_first_trans_delta(t22, 2U, 1, 0LL);

LAB2:    t27 = (t0 + 17936);
    *((int *)t27) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_17(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    int t4;
    int t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    int t14;
    int t15;
    int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned char t20;
    unsigned char t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;

LAB0:    xsi_set_current_line(316, ng0);

LAB3:    t1 = (t0 + 10136U);
    t2 = *((char **)t1);
    t1 = (t0 + 11672U);
    t3 = *((char **)t1);
    t4 = *((int *)t3);
    t5 = (t4 - 1);
    t6 = (t5 - 4);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t1 = (t2 + t9);
    t10 = *((unsigned char *)t1);
    t11 = (t0 + 8856U);
    t12 = *((char **)t11);
    t11 = (t0 + 11672U);
    t13 = *((char **)t11);
    t14 = *((int *)t13);
    t15 = (t14 - 1);
    t16 = (t15 - 4);
    t17 = (t16 * -1);
    t18 = (1U * t17);
    t19 = (0 + t18);
    t11 = (t12 + t19);
    t20 = *((unsigned char *)t11);
    t21 = ieee_p_2592010699_sub_3488546069778340532_503743352(IEEE_P_2592010699, t10, t20);
    t22 = (t0 + 19152);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    t25 = (t24 + 56U);
    t26 = *((char **)t25);
    *((unsigned char *)t26) = t21;
    xsi_driver_first_trans_delta(t22, 1U, 1, 0LL);

LAB2:    t27 = (t0 + 17952);
    *((int *)t27) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_18(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned char t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;

LAB0:    xsi_set_current_line(319, ng0);

LAB3:    t1 = (t0 + 10136U);
    t2 = *((char **)t1);
    t3 = (3 - 4);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 8856U);
    t9 = *((char **)t8);
    t10 = (3 - 4);
    t11 = (t10 * -1);
    t12 = (1U * t11);
    t13 = (0 + t12);
    t8 = (t9 + t13);
    t14 = *((unsigned char *)t8);
    t15 = ieee_p_2592010699_sub_3488768496604610246_503743352(IEEE_P_2592010699, t7, t14);
    t16 = (t0 + 19216);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t15;
    xsi_driver_first_trans_fast_port(t16);

LAB2:    t21 = (t0 + 17968);
    *((int *)t21) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0814251715_3212880686_p_19(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(321, ng0);

LAB3:    t1 = (t0 + 8856U);
    t2 = *((char **)t1);
    t3 = (3 + 1);
    t4 = (t3 - 4);
    t5 = (t4 * -1);
    t6 = (1U * t5);
    t7 = (0 + t6);
    t1 = (t2 + t7);
    t8 = *((unsigned char *)t1);
    t9 = (t0 + 19280);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t8;
    xsi_driver_first_trans_fast_port(t9);

LAB2:    t14 = (t0 + 17984);
    *((int *)t14) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0814251715_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0814251715_3212880686_p_0,(void *)work_a_0814251715_3212880686_p_1,(void *)work_a_0814251715_3212880686_p_2,(void *)work_a_0814251715_3212880686_p_3,(void *)work_a_0814251715_3212880686_p_4,(void *)work_a_0814251715_3212880686_p_5,(void *)work_a_0814251715_3212880686_p_6,(void *)work_a_0814251715_3212880686_p_7,(void *)work_a_0814251715_3212880686_p_8,(void *)work_a_0814251715_3212880686_p_9,(void *)work_a_0814251715_3212880686_p_10,(void *)work_a_0814251715_3212880686_p_11,(void *)work_a_0814251715_3212880686_p_12,(void *)work_a_0814251715_3212880686_p_13,(void *)work_a_0814251715_3212880686_p_14,(void *)work_a_0814251715_3212880686_p_15,(void *)work_a_0814251715_3212880686_p_16,(void *)work_a_0814251715_3212880686_p_17,(void *)work_a_0814251715_3212880686_p_18,(void *)work_a_0814251715_3212880686_p_19};
	xsi_register_didat("work_a_0814251715_3212880686", "isim/Forward_converter_Top_Model_isim_beh.exe.sim/work/a_0814251715_3212880686.didat");
	xsi_register_executes(pe);
}
