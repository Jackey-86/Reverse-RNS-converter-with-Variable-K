/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/VM_files/RNS - Foward Converter/TestBench.vhd";
extern char *STD_TEXTIO;
extern char *IEEE_P_1242562249;
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3564397177;

char *ieee_p_1242562249_sub_10420449594411817395_1035706684(char *, char *, int , int );
int ieee_p_1242562249_sub_17802405650254020620_1035706684(char *, char *, char *);
unsigned char ieee_p_2592010699_sub_13554554585326073636_503743352(char *, char *, unsigned int , unsigned int );
void ieee_p_3564397177_sub_2250825304603680424_91900896(char *, char *, char *, char *, char *, unsigned char , int );


static void work_a_1973892862_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 3720U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 4744);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 3528);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(71, ng0);
    t2 = (t0 + 4744);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(72, ng0);
    t2 = (t0 + 2568U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 3528);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_1973892862_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    int64 t5;

LAB0:    t1 = (t0 + 3968U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(79, ng0);
    t3 = (20 * 1000LL);
    t2 = (t0 + 3776);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(81, ng0);
    t2 = (t0 + 2568U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t5 = (t3 * 10);
    t2 = (t0 + 3776);
    xsi_process_wait(t2, t5);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(83, ng0);

LAB14:    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

LAB12:    goto LAB2;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

}

static void work_a_1973892862_3212880686_p_2(char *t0)
{
    char t6[16];
    char t17[8];
    char t18[8];
    char t19[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    int64 t11;
    int t12;
    char *t13;
    unsigned char t14;
    unsigned char t15;
    int t16;
    unsigned char t21;
    unsigned int t22;
    char *t23;
    char *t24;

LAB0:    t1 = (t0 + 4216U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(91, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7777);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 31;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (31 - 1);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(92, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 2896U);
    t4 = (t0 + 3072U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(94, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7808);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 8;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (8 - 1);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(95, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7816);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 10;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (10 - 1);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(96, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7826);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 10;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (10 - 1);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(97, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7836);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 10;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (10 - 1);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(98, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 2896U);
    t4 = (t0 + 3072U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7846);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (0 - 1);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(100, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 2896U);
    t4 = (t0 + 3072U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(102, ng0);
    t2 = (t0 + 4808);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(103, ng0);
    t11 = (10 * 1000LL);
    t2 = (t0 + 4024);
    xsi_process_wait(t2, t11);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(107, ng0);
    t2 = (t0 + 7846);
    *((int *)t2) = 0;
    t3 = (t0 + 7850);
    *((int *)t3) = 4079;
    t9 = 0;
    t12 = 4079;

LAB8:    if (t9 <= t12)
        goto LAB9;

LAB11:    goto LAB2;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB9:    xsi_set_current_line(108, ng0);
    t4 = (t0 + 4808);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    t8 = (t7 + 56U);
    t13 = *((char **)t8);
    *((unsigned char *)t13) = (unsigned char)2;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(109, ng0);
    t2 = (t0 + 7846);
    t3 = ieee_p_1242562249_sub_10420449594411817395_1035706684(IEEE_P_1242562249, t6, *((int *)t2), 12);
    t4 = (t0 + 4872);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    t8 = (t7 + 56U);
    t13 = *((char **)t8);
    memcpy(t13, t3, 12U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(110, ng0);
    t2 = (t0 + 7854);
    t4 = (t0 + 4936);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    t8 = (t7 + 56U);
    t13 = *((char **)t8);
    memcpy(t13, t2, 2U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(111, ng0);

LAB14:    t2 = (t0 + 4536);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB10:    t2 = (t0 + 7846);
    t9 = *((int *)t2);
    t3 = (t0 + 7850);
    t12 = *((int *)t3);
    if (t9 == t12)
        goto LAB11;

LAB46:    t16 = (t9 + 1);
    t9 = t16;
    t4 = (t0 + 7846);
    *((int *)t4) = t9;
    goto LAB8;

LAB12:    t3 = (t0 + 4536);
    *((int *)t3) = 0;
    xsi_set_current_line(112, ng0);

LAB18:    t2 = (t0 + 4552);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB13:    t3 = (t0 + 1512U);
    t4 = *((char **)t3);
    t14 = *((unsigned char *)t4);
    t15 = (t14 == (unsigned char)3);
    if (t15 == 1)
        goto LAB12;
    else
        goto LAB14;

LAB15:    goto LAB13;

LAB16:    t4 = (t0 + 4552);
    *((int *)t4) = 0;
    xsi_set_current_line(115, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t4 = (t0 + 7624U);
    t16 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t5, t4);
    std_textio_write5(STD_TEXTIO, t2, t3, t16, (unsigned char)0, 0);
    xsi_set_current_line(116, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7856);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 17;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (17 - 1);
    t10 = (t16 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 1672U);
    t5 = *((char **)t4);
    t4 = (t0 + 7640U);
    t16 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t5, t4);
    std_textio_write5(STD_TEXTIO, t2, t3, t16, (unsigned char)0, 0);
    xsi_set_current_line(118, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7873);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 1;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (1 - 1);
    t10 = (t16 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(119, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 1832U);
    t5 = *((char **)t4);
    t4 = (t0 + 7656U);
    t16 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t5, t4);
    std_textio_write5(STD_TEXTIO, t2, t3, t16, (unsigned char)0, 0);
    xsi_set_current_line(120, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7874);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 1;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (1 - 1);
    t10 = (t16 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(121, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 1992U);
    t5 = *((char **)t4);
    t4 = (t0 + 7672U);
    t16 = ieee_p_1242562249_sub_17802405650254020620_1035706684(IEEE_P_1242562249, t5, t4);
    std_textio_write5(STD_TEXTIO, t2, t3, t16, (unsigned char)0, 0);
    xsi_set_current_line(122, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7875);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 1;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (1 - 1);
    t10 = (t16 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(126, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7876);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 18;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (18 - 1);
    t10 = (t16 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(129, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 1672U);
    t5 = *((char **)t4);
    memcpy(t17, t5, 4U);
    t4 = (t0 + 7640U);
    ieee_p_3564397177_sub_2250825304603680424_91900896(IEEE_P_3564397177, t2, t3, t17, t4, (unsigned char)0, 0);
    xsi_set_current_line(130, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7894);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 3;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (3 - 1);
    t10 = (t16 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(132, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 1832U);
    t5 = *((char **)t4);
    memcpy(t18, t5, 6U);
    t4 = (t0 + 7656U);
    ieee_p_3564397177_sub_2250825304603680424_91900896(IEEE_P_3564397177, t2, t3, t18, t4, (unsigned char)0, 0);
    xsi_set_current_line(134, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7897);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 3;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (3 - 1);
    t10 = (t16 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(135, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 1992U);
    t5 = *((char **)t4);
    memcpy(t19, t5, 4U);
    t4 = (t0 + 7672U);
    ieee_p_3564397177_sub_2250825304603680424_91900896(IEEE_P_3564397177, t2, t3, t19, t4, (unsigned char)0, 0);
    xsi_set_current_line(136, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7900);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (0 - 1);
    t10 = (t16 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(137, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 2896U);
    t4 = (t0 + 3072U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(138, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 3072U);
    t4 = (t0 + 7900);
    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t16 = (0 - 1);
    t10 = (t16 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t6, (unsigned char)0, 0);
    xsi_set_current_line(139, ng0);
    t2 = (t0 + 4024);
    t3 = (t0 + 2896U);
    t4 = (t0 + 3072U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(141, ng0);
    t2 = (t0 + 4808);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t7 = *((char **)t5);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(142, ng0);
    t2 = (t0 + 2568U);
    t3 = *((char **)t2);
    t11 = *((int64 *)t3);
    t2 = (t0 + 4024);
    xsi_process_wait(t2, t11);

LAB22:    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB17:    t3 = (t0 + 1152U);
    t14 = ieee_p_2592010699_sub_13554554585326073636_503743352(IEEE_P_2592010699, t3, 0U, 0U);
    if (t14 == 1)
        goto LAB16;
    else
        goto LAB18;

LAB19:    goto LAB17;

LAB20:    xsi_set_current_line(143, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t2 = (t0 + 7900);
    t15 = 1;
    if (12U == 12U)
        goto LAB30;

LAB31:    t15 = 0;

LAB32:    if (t15 == 1)
        goto LAB27;

LAB28:    t14 = (unsigned char)0;

LAB29:    if (t14 != 0)
        goto LAB24;

LAB26:
LAB25:    goto LAB10;

LAB21:    goto LAB20;

LAB23:    goto LAB21;

LAB24:    xsi_set_current_line(144, ng0);

LAB44:    *((char **)t1) = &&LAB45;
    goto LAB1;

LAB27:    t8 = (t0 + 2152U);
    t13 = *((char **)t8);
    t8 = (t0 + 7912);
    t21 = 1;
    if (2U == 4U)
        goto LAB36;

LAB37:    t21 = 0;

LAB38:    t14 = t21;
    goto LAB29;

LAB30:    t10 = 0;

LAB33:    if (t10 < 12U)
        goto LAB34;
    else
        goto LAB32;

LAB34:    t5 = (t3 + t10);
    t7 = (t2 + t10);
    if (*((unsigned char *)t5) != *((unsigned char *)t7))
        goto LAB31;

LAB35:    t10 = (t10 + 1);
    goto LAB33;

LAB36:    t22 = 0;

LAB39:    if (t22 < 2U)
        goto LAB40;
    else
        goto LAB38;

LAB40:    t23 = (t13 + t22);
    t24 = (t8 + t22);
    if (*((unsigned char *)t23) != *((unsigned char *)t24))
        goto LAB37;

LAB41:    t22 = (t22 + 1);
    goto LAB39;

LAB42:    goto LAB25;

LAB43:    goto LAB42;

LAB45:    goto LAB43;

}


extern void work_a_1973892862_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1973892862_3212880686_p_0,(void *)work_a_1973892862_3212880686_p_1,(void *)work_a_1973892862_3212880686_p_2};
	xsi_register_didat("work_a_1973892862_3212880686", "isim/Generic_forward_converter_TB_isim_beh.exe.sim/work/a_1973892862_3212880686.didat");
	xsi_register_executes(pe);
}
