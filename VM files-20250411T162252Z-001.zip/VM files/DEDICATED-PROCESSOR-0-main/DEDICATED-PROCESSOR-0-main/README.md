# DEDICATED-PROCESSOR-

### Architecture
    * Datapath
    * Control Unit
    * 7-segment display controller
    * 

### Components
